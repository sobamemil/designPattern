import java.util.Random;

public class PrimeNumberGenerator extends NumberGenerator {
    private Random random = new Random(); // 난수발생기
    private int number; // 현재의 수

    public int getNumber() { // 수를 취득함
        return number;
    }

    public void execute() {
        for(int i=0; i<20; i++) {
            while(true) {
                number = random.nextInt(50);
                if (isPrime(number)) { // 결과가 true면 소수
                    break;
                }
            }
            notifyObservers();
        }
    }

    // 소수 판별 메소드
    private boolean isPrime(int number) {

        // 0 과 1 은 소수가 아님
        if(number < 2) { return false; }

        // 2 는 소수
        if(number == 2) { return true; }

        // Math.sqrt()-> 제곱근 메소드
        for(int i = 2; i <= Math.sqrt(number); i++) {
            // 소수가 아닐경우
            if(number % i == 0) { return false; }
        }
        // 소수인 경우
        return true;
    }
}
