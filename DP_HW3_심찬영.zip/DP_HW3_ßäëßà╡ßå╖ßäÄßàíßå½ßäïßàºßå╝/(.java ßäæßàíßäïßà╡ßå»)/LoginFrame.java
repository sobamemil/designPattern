import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends Frame implements ActionListener, Mediator {
    private ColleagueCheckbox checkGuest;
    private ColleagueCheckbox checkLogin;
    private ColleagueCheckbox checkMember; // 라디오 박스에 member 추가
    private ColleagueTextField textUser;
    private ColleagueTextField textPass;
    private ColleagueTextField textRRN; // resident registration number(주민등록번호) 추가
    private ColleagueButton buttonOk;
    private ColleagueButton buttonCancel;

    // 생성자
    // Colleague들을 생성하고, 배치한 후에 표시를 실행함
    public LoginFrame(String title) {
        super(title);
        setBackground(Color.lightGray);
        // 레이아웃 매니저를 사용해서 5x3의 그리드로 변경
        setLayout(new GridLayout(5, 3)); // 변경
        // Colleague들의 생성
        createColleagues();
        // 배치
        add(checkGuest);
        add(checkLogin);
        add(checkMember);
        add(new Label("Username:"));
        add(textUser);
        add(new Label("")); // 칸을 띄우기 위함 // 추가
        add(new Label("Password:"));
        add(textPass);
        add(new Label("")); // 칸을 띄우기 위함 // 추가
        add(new Label("주민등록번호")); // 주민등록번호 text 추가
        add(textRRN); // resident registration number 텍스트필드 추가
        add(new Label("")); // 칸을 띄우기 위함 // 추가
        add(buttonOk);
        add(buttonCancel);
        // 유효/무효의 초기 지정
        colleagueChanged();
        // 표시
        pack();
        show();
    }

    //Colleague들을 생성
    public void createColleagues() {
        // 생성
        CheckboxGroup g = new CheckboxGroup();
        checkGuest = new ColleagueCheckbox("Guest", g, true);
        checkLogin = new ColleagueCheckbox("Login", g, false);
        checkMember = new ColleagueCheckbox("Member", g, false); // 추가
        textUser = new ColleagueTextField("", 10);
        textPass = new ColleagueTextField("", 10);
        textPass.setEchoChar('*');
        textRRN = new ColleagueTextField("", 13); // 추가
        buttonOk = new ColleagueButton("OK");
        buttonCancel = new ColleagueButton("Cancel");

        // Mediator의 세트
        checkGuest.setMediator(this);
        checkLogin.setMediator(this);
        checkMember.setMediator(this); // 추가
        textUser.setMediator(this);
        textPass.setMediator(this);
        textRRN.setMediator(this); // 추가
        buttonOk.setMediator(this);
        buttonCancel.setMediator(this);

        //Listener의 세트
        checkGuest.addItemListener(checkGuest);
        checkLogin.addItemListener(checkLogin);
        checkMember.addItemListener(checkMember); // 추가
        textUser.addTextListener(textUser);
        textPass.addTextListener(textPass);
        textRRN.addTextListener(textRRN); // 추가
        buttonOk.addActionListener(this);
        buttonCancel.addActionListener(this);
    }

    // Colleague에서의 통지로 Colleague의 유효/무효를 판정
    public void colleagueChanged() {
        if(checkGuest.getState()) { // Guest 모드
            textUser.setColleagueEnabled(false);
            textPass.setColleagueEnabled(false);
            textRRN.setColleagueEnabled(false); // RRN 필드 false // 추가
            buttonOk.setColleagueEnabled(true);
        } else if(checkLogin.getState()) { // Login 모드 // 과제에 맞게 코드 변경 부분
            textUser.setColleagueEnabled(true);
            textRRN.setColleagueEnabled(false); // RRN 필드 false // 추가
            userpassChanged();
        } else { // Member 모드 // 추가
            textUser.setColleagueEnabled(true); // Username 활성화
            textPass.setColleagueEnabled(true); // Password 활성화
            textRRN.setColleagueEnabled(true); // RRN 활성화
            rrnChanged(); // 추가
        }
    }

    // textUser 또는 textPass의 변경이 있었음
    // 각 Colleague의 유효/무효를 판정
    private void userpassChanged() {
        if(textUser.getText().length() > 0) {
            textPass.setColleagueEnabled(true);
            if(textPass.getText().length() > 0) {
                buttonOk.setColleagueEnabled(true);
            } else {
                buttonOk.setColleagueEnabled(false);
            }
        } else {
            textPass.setColleagueEnabled(false);
            buttonOk.setColleagueEnabled(false);
        }
    }

    // RRN의 변경이 있었음
    // 각 Colleague의 유효/무효를 판정
    private void rrnChanged() {
        // 주민등록번호를 13자리 입력 시
        if (textRRN.getText().length() == 13) {
            String text = textRRN.getText(); // RRN 텍스트 필드의 텍스트 가져옴
            boolean ok = false; // 13자리가 전부 숫자인지 알려주는 값
            for(char word: text.toCharArray()) { // text를 하나하나 순회
                // 만약 하나라도 숫자가 아니면 ok값을 true로 설정
                if( !(word <= 57 && word >= 47)) {
                    ok = true;
                    break;
                }
            }
            if(!ok) { // 13자리가 전부 숫자라면
                // ok 버튼을 활성화 시켜줌
                buttonOk.setColleagueEnabled(true);
            }
        } else { // 주민등록번호가 13자리가 아닐 경우 ok 버튼 비활성화
            buttonOk.setColleagueEnabled(false);
        }
    }

    public void actionPerformed(ActionEvent e) {
        System.out.println(e.toString());
        System.exit(0);
    }
}
