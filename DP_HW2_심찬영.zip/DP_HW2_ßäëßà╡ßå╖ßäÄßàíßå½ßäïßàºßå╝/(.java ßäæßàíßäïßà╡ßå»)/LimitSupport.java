public class LimitSupport extends Support {
    // limit에서 지정한 번호 미만의 트러블만 해결하는 클래스
    private int limit; // 이 번호 미만이면 해결할 수 있음
    public LimitSupport(String name, int limit) { // 생성자
        super(name);
        this.limit = limit;
    }

    protected boolean resolve(Trouble trouble) { // 해결용 메소드
        if(trouble.getNumber() < this.limit) {
            return true;
        } else {
            return false;
        }
    }
}
