package drawer;
import command.Command;
import java.awt.*;

public class ColorCommand implements Command {
    // 그림 그리는 대상
    protected Drawable drawable;
    // 페인트 색상
    protected Color color;
    // 생성자
    public ColorCommand(Drawable drawable, Color color) {
        this.drawable = drawable;
        this.color = color;
    }
    // 실행
    public void execute() {
        drawable.setColor(color);
    }
}
