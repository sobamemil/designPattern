import java.util.ArrayList;
import java.util.Iterator;

public class FileNameFindVisitor extends Visitor {
    private String name;
    private ArrayList files;

    {
        files = new ArrayList();
    }

    public Iterator getFoundFiles() {
        return files.iterator();
    }

    public FileNameFindVisitor(String name) {
        this.name = name;
    }

    public void visit(File file) {
        if(file.getName().contains(this.name)) {
            files.add(file);
        }
    }

    public void visit(Directory directory) {
        Iterator it = directory.iterator();
        while(it.hasNext()) {
            Entry entry = (Entry) it.next();
            entry.accept(this);
        }
    }
}
