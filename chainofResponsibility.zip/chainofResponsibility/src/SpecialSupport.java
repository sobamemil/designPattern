public class SpecialSupport extends Support {
    // 지정한 번호의 트러블만 처리하는 클래스
    private int number; // 이 번호만 해결할 수 있음
    public SpecialSupport(String name, int number) { // 생성자
        super(name);
        this.number = number;
    }

    protected boolean resolve(Trouble trouble) { // 해결용 메소드
        if(trouble.getNumber() == number) {
            return true;
        } else {
            return false;
        }
    }
}
