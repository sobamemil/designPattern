import static java.lang.Math.sqrt;

public class HwSupport extends Support {
    // 트러블 번호가 소수인 경우에만 처리하는 클래스
    public HwSupport(String name) {
        super(name);
    }

    public Boolean calcPrimeNumber(int number) { // 소수인지 확인해주는 메소드
        if( number == 1 )
            return false; //1은 소수가 아님

        // 짝수 중 2만 유일한 소수
        if( (number % 2) == 0) {
            if(number == 2) {
                return true;
            } else {
                return false;
            }
        }

        // n이 홀수인 경우 sqrt(n) 까지 나눠서 나눠 떨어지는지 확인
        for(int i=3; i<=sqrt(number); i += 2) {
            if( number % i == 0) // 나누어 떨어지는 숫자가 있으므로 소수가 아님
                return false;
        }
        // 나머지 경우 소수로 판별
        return true;
    }

    protected boolean resolve(Trouble trouble) { // 해결용 메소드
        if(calcPrimeNumber(trouble.getNumber())) {
            return true;
        } else {
            return false;
        }
    }
}
