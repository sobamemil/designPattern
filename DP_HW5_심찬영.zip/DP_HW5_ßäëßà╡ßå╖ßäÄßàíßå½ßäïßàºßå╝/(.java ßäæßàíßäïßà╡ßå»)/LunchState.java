public class LunchState implements State {
    private static LunchState singleton = new LunchState();

    private LunchState() { // 생성자는 private

    }

    public static State getInstance() { // 유일한 인스턴스를 얻음
        return singleton;
    }

    public void doClock(Context context, int hour) { // 시간설정
        if(hour >= 13) {
            context.changeState(DayState.getInstance());
        }
    }

    public void doUse(Context context) { // 금고사용
        context.callSecurityCenter("비상 : 점심시간 금고 사용!");
    }

    public void doAlarm(Context context) { // 비상벨
        context.callSecurityCenter("비상벨(점심시간)");
    }

    public void doPhone(Context context) { // 일반통화
        context.callAnsweringMachine("자동응답기(점심시간)");
    }

    public String toString() { // 문자열 표현
        return "[점심시간]";
    }
}
